# Sistema de Reservas con SINPE + WhatsApp

Este es un sistema web simple para reservas en línea que funciona con:

- React + Vite
- Firebase Firestore
- TailwindCSS
- Confirmación por WhatsApp
- Pagos manuales con SINPE móvil (Costa Rica)

## 🚀 Instrucciones

1. Clona este repositorio:
   ```bash
   git clone https://github.com/tu-usuario/sistema-reservas-sinpe.git
   cd sistema-reservas-sinpe
   ```

2. Instala dependencias:
   ```bash
   npm install
   ```

3. Configura tu Firebase en `src/firebase/config.js`

4. Ejecuta local:
   ```bash
   npm run dev
   ```

5. Para subir a Vercel:
   - Sube el proyecto a GitHub
   - Conecta tu cuenta de Vercel
   - Selecciona este repositorio
   - Confirma la build con: `vite` y directorio de salida `dist`

✅ Listo para aceptar reservas con confirmación vía WhatsApp y pagos con SINPE móvil.
